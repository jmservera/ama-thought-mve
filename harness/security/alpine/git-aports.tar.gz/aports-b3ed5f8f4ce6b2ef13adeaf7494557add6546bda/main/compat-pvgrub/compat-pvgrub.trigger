#!/bin/sh

update-pvgrub
