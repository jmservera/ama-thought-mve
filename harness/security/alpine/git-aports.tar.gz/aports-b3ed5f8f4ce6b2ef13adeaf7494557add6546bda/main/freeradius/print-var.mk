print-%:
	@echo '$($*)'
