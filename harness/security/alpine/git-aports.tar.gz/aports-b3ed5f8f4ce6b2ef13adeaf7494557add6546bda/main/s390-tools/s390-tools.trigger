#!/bin/sh

zipl --verbose
